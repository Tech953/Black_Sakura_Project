# Rebecca reference pack for Task #798

This ZIP contains the actual audio-bearing portable reference pack shipped at examples/rebecca_reference_pack in FULL_REZZ 3.0. The original manifest, profile ID, pack ID, audio and source files are unchanged. manifest.json is at the ZIP root; every clip/source path is relative to that root. Recovered from FULL_REZZ_3.0_Replit_Source_Core.zip (SHA-256 252149de3861dd56d65e85f3e25020f4bf475c89dd4bb8d9cff19d4ae721d1eb).

For ENGRAM, read manifest.json and select the profile voice_57373fea79f3473e. Its pack ID is pack_27e39b3817c8490d. Select the reference style concern. TASK_798_BINDING.json gives the exact clip path, transcript and SHA-256. Load the real WAV bytes and this reference transcript into the existing local reference-conditioned renderer. Keep paths under the extracted pack root. This is the conditioning reference, not a previously generated reply.

There is ONE eligible reference: 4.35 seconds, 44,100 Hz, mono IEEE Float32 WAV. The transcript is retained exactly as authored in the manifest. Other entries in transcript.jsonl/segments.csv are historical recording annotations, not additional exported voice references. The portable pack includes clips, character context, source documents, transcripts/subtitles and quality evidence; original full-length recordings are retained by the originating application and are not required by the reference SDK.

The original export's schema is 1.1.0 and producer_version is 1.2.1. Those provenance fields are intentionally preserved; the supplied FULL_REZZ 3.0 reference bridge and voice SDK accept this schema, and both selected and hash-checked the actual reference in this delivery check. Do not rename it to a new export or change IDs merely to match an application version.

Attach this reference to the existing intended ENGRAM character. Preserve the newer profile/audit JSON already supplied. If importing creates new local IDs, use the import receipt's explicit mapping rather than assuming the original profile ID is the new local one. No generic voice is an automatic substitute. Reference purity is user_declared_single_voice, not a completed listening approval. Identity, naturalness and likeness remain pending human review.

No neural model weights, runtime, cloud speech service or microphone-to-transcription wiring are added by this ZIP. Use the already configured local models/worker. Live Task #798 integration was not executed here. PACK_VALIDATION.json records byte/audio/SDK verification; FILES.sha256 covers all other files in this ZIP except itself.
