FULL_REZZ 3.0 - Refreshed guide set
15 October 2026 | Download revision 2026-10-14.3

The four PDFs provide the quick start, complete user guide, product audit,
and Replit integration guide. Editable Markdown sources are included.
These instructions describe the current 15-ZIP installer transport and
the compact Replit source ZIP. Extract only Recovery_Tools.zip beside the
15 installer ZIPs; leave those ZIPs zipped and run Assemble_Installer.cmd.
Use the full filenames in the guides when choosing downloads.

This set refreshes documentation and download delivery. The application,
installer executable and source archives have not been rebuilt here.
Guides stored inside those earlier archives remain dated; use this set
for current download and assembly instructions.

The audit distinguishes preserved test evidence from uncompleted native
Windows, signed-in Replit and host ENGRAM acceptance. Artistic and voice
review remain open. It does not certify studio-equivalent quality.

CHECKSUMS.sha256 verifies the exact files INSIDE this ZIP. Separately
downloaded PDFs may carry additional provenance metadata; their bytes
can differ while their visible guide content remains the same.
